// function find_max_num(no1, no2) {
//     return (no1 > no2 ? no1:no2)
// }

// let max = find_max_num(5,10);
// console.log(max)