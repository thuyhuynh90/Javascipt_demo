// function checkSpeed(speed) {
//     if (speed <= 70)
//         return 'ok';
//     else {
//         let over = Math.floor((speed-70)/5);
//         if (over < 12)
//             return ("point: " + over)
//         return "point: " + over + ' => suspended';
//     }
// }


// let penalty = checkSpeed(182);
// console.log(penalty);