// function fizzBuzz(i) {
//     if (typeof i!=='number') return "Not a number";
//     else if (i%3===0 && i%5===0) return 'FizzBuzz';
//     else if (i%3===0) return 'Fizz';
//     else if (i%5===0) return 'Buzz';
//     return i;
// }

// const output = fizzBuzz(7);
// console.log(output);