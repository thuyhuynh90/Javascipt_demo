// const movie = {
//     title: 'a',
//     releaseYear: 2023,
//     rating: 4.5,
//     director: 'Bill'
// };
// showStrProperties(movie);

// function showStrProperties(obj) {
//     for (let key in obj)
//         if (typeof obj[key] === "string")
//             console.log(key + " " + obj[key]);
// }