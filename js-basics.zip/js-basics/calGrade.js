// const marks = [80, 80, 50];

// console.log(calculateGrade(marks));

// function calculateGrade(marks) {
//     let sum = 0;
//     let count = 0;
    
//     for (let value of marks){
//         count += 1;
//         sum = sum + value;
//     }
    
//     let average = sum/count;
//     console.log("Average: " + average);

//    if (average < 60)
//         return 'Grade: F';
//     else if (average < 70)
//         return 'Grade: D';
//     else if (average < 80)
//         return 'Grade: C';
//     else if (average < 90)
//         return 'Grade: B';
//     else
//         return 'Grade: A';
// }