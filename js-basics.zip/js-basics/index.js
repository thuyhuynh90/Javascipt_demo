// //firstName and lastName are parameter, it define variable in function
// //Thuy and Huynh are argument, it is a real value of parameter
// function greet(firstName, lastName) { 
//     console.log("Function say Hi with " + firstName + ' ' + lastName);
// }
// greet('Thuy','Huynh')

// function square(num) {
//     return num*num;
// }
// let number = square(2)
// console.log(number)

// //Ternary Operations or Conditional Operation
// /* 
// If a customer has more than 100 points,
// they are a 'gold' customer, otherwise,
// they are a 'silver' customer
// */
// let points = 80;
// let type = points > 100 ? 'gold':'silver';

// console.log(type);

/* If...else condition
if (condition) {
    statement
}
else if (condition) {
    statement(s)
}
else {
    statement
}    */
// let hour = 12;
// if (hour >= 6 && hour <=12)
//     console.log("Good morning!")
// else if (hour > 12 && hour <= 18)
//     console.log("Good afternoon!")
// else 
//     console.log("Good Evening!")

/** switch...case */
// let role = "guest";

// switch (role) {
//     case ('guest'):
//         console.log("Hello guest!");
//         break;
//     case ('moderator'):
//         console.log("Hello Moderator");
//         break;
//     default:
//         console.log("Unknowned User");
// }

//For loop
// for (let i = 0; i < 5; i++) {
//     if (i%2!==0) console.log(i);
// }

//while loop
// let i = 0;
// while(i<5) {
//     if (i%2!==0) console.log(i);
//     i++;
// }

//Do...While loop
// let i = 0;
// do {
//     if (i%2!==0) console.log(i);
//     i++;
// }
// while (i<5)

//for-in loop
// const person = {
//     name: "Thuy",
//     age: 30
// }
// for (let key in person)
//     console.log(key, person[key])

// const colors = ['red', 'blue', 'yellow'];
// for (let index in colors)
//     console.log(index, colors[index])

//for...of loop
// for (let color of colors)
//     console.log(color)