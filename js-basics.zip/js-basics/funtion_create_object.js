// //Factory function: function to create a object to use many places
// function createCircle(radius) {
//     return{
//         radius,
//         draw(){
//             console.log('draw');
//         }
//     };
// }

// const circle1 = createCircle(1);
// console.log(circle1);   

// //Constructor function
// function Circle(radius) {
//     this.radius;
//     this.draw = function() {
//         console.log('draw');
//     }
// }
// const circle2 = new Circle(5)
// console.log(circle2)