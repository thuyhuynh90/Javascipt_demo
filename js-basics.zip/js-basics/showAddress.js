// function showAddress() {
//     return {
//         street: 'Phan Xich Long',
//         city: 'Ho Chi Minh',
//         zipCode: 700000
//     }
// }

// console.log(showAddress());

const address = {
    street: 'Phan Xich Long',
    city: 'Ho Chi Minh',
    zipCode: 700000
}

function showAddress(address) {
    for (let key in address)
        console.log(key, address[key]);
}

showAddress(address);